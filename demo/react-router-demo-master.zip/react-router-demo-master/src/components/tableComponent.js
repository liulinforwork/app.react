import React from 'react';

export default class TableComponent extends React.Component{
	render(){
		return (
			<div>我是tableComponent组件</div>
		);
	}
}