# react-router-demo
react-router 4.0  demo


这个demo主要是对react-router 4.0的一些改变做的demo

查看方法：
讲项目拉到本地
npm install
webpack-dev-server

浏览器打开：http://localhost:8081/  即可看到
